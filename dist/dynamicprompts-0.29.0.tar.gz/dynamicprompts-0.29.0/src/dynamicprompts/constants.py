from __future__ import annotations

from random import Random

DEFAULT_ENCODING = "utf-8"
DEFAULT_COMBO_JOINER = ","
MAX_IMAGES = 1000
DEFAULT_RANDOM = Random()
