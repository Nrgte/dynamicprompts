from dynamicprompts.wildcards.collection.base import WildcardCollection
from dynamicprompts.wildcards.collection.text_file import WildcardTextFile

__all__ = [
    "WildcardCollection",
    "WildcardTextFile",
]
